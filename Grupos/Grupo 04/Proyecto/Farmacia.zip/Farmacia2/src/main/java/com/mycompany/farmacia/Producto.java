package com.mycompany.farmacia;

public abstract class Producto {
    protected String nombre;
    protected String codigo;
    protected double precio;
    protected int stockDisponible;
    protected boolean requiereReceta;

    public Producto(String nombre, String codigo, double precio, int stockDisponible, boolean requiereReceta) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;
        this.stockDisponible = stockDisponible;
        this.requiereReceta = requiereReceta;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public String getCodigo() { return codigo; }
    public double getPrecio() { return precio; }
    public boolean isRequiereReceta() { return requiereReceta; }
    public int getStockDisponible() { return stockDisponible; }
    public void setStockDisponible(int stockDisponible) { this.stockDisponible = stockDisponible; }

    // Método para simular la venta (modifica el stock)
    public boolean vender(int cantidad) {
        if (this.stockDisponible >= cantidad) {
            this.stockDisponible -= cantidad;
            return true;
        }
        return false;
    }

    // Método polimórfico para mostrar información
    public void mostrarInfo() {
        String reqReceta = requiereReceta ? "Sí" : "No";
        System.out.printf("CÓD: %s | Nombre: %s | Precio: $%.2f | Stock: %d | Req. Receta: %s",
            codigo, nombre, precio, stockDisponible, reqReceta);
    }
}