package com.mycompany.farmacia;

public class Empleado extends Persona {
    private String usuario;
    private String password;
    
    public Empleado(String nombre, String id, String usuario, String password) {
        super(nombre, id); 
        this.usuario = usuario;
        this.password = password;
    }

    public String getUsuario() { return usuario; }
    public String getPassword() { return password; }
    
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Usuario: " + usuario);
    }
}