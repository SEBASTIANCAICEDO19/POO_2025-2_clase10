package com.mycompany.farmacia;

public class ArticuloGeneral extends Producto {
    
    public ArticuloGeneral(String nombre, String codigo, double precio, int stockDisponible) {
        // Los artículos generales nunca requieren receta (false)
        super(nombre, codigo, precio, stockDisponible, false); 
    }
    
    @Override // Polimorfismo
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.printf(" | Tipo: Artículo General\n");
    }
}