package com.mycompany.farmacia;

public class Persona {
    private String nombre;
    private String id;

    public Persona(String nombre, String id) {
        this.nombre = nombre;
        this.id = id;
    }

    public String getNombre() { return nombre; }
    public String getId() { return id; }

    // Método polimórfico
    public void mostrarInfo() {
        System.out.println("--- Información Personal ---");
        System.out.println("Nombre: " + nombre);
        System.out.println("ID: " + id);
    }
}