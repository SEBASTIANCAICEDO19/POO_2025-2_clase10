package com.mycompany.farmacia;

import GUI.LoginWindow;
import Conexión.FarmaciaDAO;
import java.util.ArrayList;
import java.util.List;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane; 

public class Farmacia {
    private String nombreSistema;
    private List<Producto> productos;
    private List<Cliente> clientes;
    private List<Venta> historialVentas;
    private List<Empleado> empleados;
    
    // Atributos Financieros
    private double ingresosTotales = 0.0;
    private double gastosTotales = 0.0; 
    
    // INSTANCIA del Data Access Object (DAO)
    private FarmaciaDAO dao; 

    public Farmacia(String nombreSistema) {
        this.nombreSistema = nombreSistema;
        
        // 1. Inicializar el DAO
        this.dao = new FarmaciaDAO(); 
        
        // 2. Inicializar colecciones 
        this.productos = new ArrayList<>();
        this.clientes = new ArrayList<>();
        this.historialVentas = new ArrayList<>();
        this.empleados = new ArrayList<>(); // Inicialización de empleados
        
        // 3. Cargar datos existentes y crear datos de prueba si es necesario
        cargarDatosInicialesDesdeBD();
        
        // 4. Inicializar Empleados de prueba para el Login
        inicializarEmpleados();
        
        System.out.println("Sistema " + nombreSistema + " iniciado.");
        
        // Gasto inicial
        this.gastosTotales = 0; 
    }
   
    private void inicializarEmpleados() {
        // Agregamos un empleado único para el login simplificado:
        // CREDENCIALES: Usuario = "user", Contraseña = "pass123"
        this.empleados.add(new Empleado("Empleado Principal", "E001", "Unal", "12345"));
        System.out.println("Cargado usuario de prueba: user/pass123");
    }

    /**
     * Intenta autenticar a un empleado.
     * usuario El nombre de usuario ingresado.
     * password La contraseña ingresada.
     * El objeto Empleado si la autenticación es exitosa, null en caso contrario.
     */
    public Empleado autenticarUsuario(String usuario, String password) {
        for (Empleado emp : empleados) {
            if (emp.getUsuario().equals(usuario) && emp.getPassword().equals(password)) {
                return emp; 
            }
        }
        return null; 
    }
    
    private void cargarDatosInicialesDesdeBD() {
        // Cargar datos de la BD y reemplazar las listas vacías
        this.productos = dao.obtenerTodosLosProductos();
        this.clientes = dao.obtenerTodosLosClientes();
        
        System.out.println("Cargados " + this.clientes.size() + " clientes y " + this.productos.size() + " productos desde la BD.");
        
        if (this.productos.isEmpty()) {
            System.out.println("BD vacía. Inicializando con datos de prueba...");
            
            registrarProducto(new Medicamento("Antibiótico Z", "7001", 6000, 10, true, "Amoxicilina"));
            registrarProducto(new ArticuloGeneral("Cepillo Dientes", "3001", 5000, 50));
            registrarCliente(new Cliente("Ana Torres", "123456", true));
            registrarCliente(new Cliente("Luis Ramos", "654321", false));
        }
    }
    
    public Cliente buscarClientePorID(String id) {
        for (Cliente c : clientes) {
            if (c.getId().equals(id)) return c;
        }
        return null;
    }

    public Producto buscarProductoPorCodigo(String codigo) {
        for (Producto p : productos) {
            if (p.getCodigo().equals(codigo)) return p;
        }
        return null;
    }

    public void registrarProducto(Producto p) {
        if (buscarProductoPorCodigo(p.getCodigo()) == null) {
            this.productos.add(p);
        }
        this.dao.registrarProducto(p); // Actualización a la BD
    }
    
    public void registrarCliente(Cliente c) {
        if (buscarClientePorID(c.getId()) == null) {
            this.clientes.add(c);
        } 
        this.dao.registrarCliente(c); // Actualización a la BD
        System.out.println(" Cliente registrado/actualizado: " + c.getNombre());
    }

    public boolean agregarStock(String codigoProducto, int cantidad) {
        Producto p = buscarProductoPorCodigo(codigoProducto);
        if (p != null) {
            int nuevoStock = p.getStockDisponible() + cantidad;
            p.setStockDisponible(nuevoStock); 
            
            if (dao.actualizarStock(codigoProducto, nuevoStock)) {
                return true;
            } else {
                p.setStockDisponible(nuevoStock - cantidad); 
                JOptionPane.showMessageDialog(null, "Error crítico: No se pudo actualizar el stock en la base de datos.");
                return false;
            }
        }
        return false;
    }
    
    //MÉTODOS DE VENTA

    public void registrarVentaTerminada(Venta ventaFinalizada) {
        this.historialVentas.add(ventaFinalizada);
        this.ingresosTotales += ventaFinalizada.getTotal();
        
        // 1. Reflejar el stock actual de cada producto vendido en la BD
        for (DetalleVenta detalle : ventaFinalizada.getCarrito()) {
            Producto p = detalle.getProducto();
            // Llama al método UPDATE del DAO
            dao.actualizarStock(p.getCodigo(), p.getStockDisponible());
        }
        
        // 2. REGISTRA LA VENTA COMPLETA EN LA BD PARA REPORTES
        dao.registrarVenta(ventaFinalizada); 
        
        System.out.println("Venta registrada en el historial. Total: " + ventaFinalizada.getTotal());
    }

    public void realizarVenta(Cliente cliente, Producto producto, int cantidad, boolean vendedorIndicaReceta) {
        // 1. Validaciones básicas de negocio
        if (producto.isRequiereReceta()) {
            if (!cliente.isTieneRecetaRegistrada() && !vendedorIndicaReceta) {
                System.out.println("VENTA DENEGADA: Falta receta médica para " + producto.getNombre());
                return;
            }
        }
        
        if (producto.getStockDisponible() < cantidad) {
             System.out.println("VENTA DENEGADA: Stock insuficiente.");
             return;
        }

        // 2. Crear venta, agregar detalle
        Venta ventaRapida = new Venta(cliente);
        
        ventaRapida.agregarDetalle(producto, cantidad); 
        
        // 3. Registrar venta
        registrarVentaTerminada(ventaRapida);
        
        // 4. Generar la factura
        ventaRapida.generarFacturaTXT();
    }
    
    //GETTERS Y SETTERS
    
    // Getters financieros
    public double getIngresosTotales() { return ingresosTotales; }
    public double getGastosTotales() { return gastosTotales; }
    public double getGananciasNetas() { return ingresosTotales - gastosTotales; }
    
    // Setters/Control de Gastos
    public void setGastosTotales(double gasto) { this.gastosTotales = gasto; }
    public void resetGastos() { this.gastosTotales = 0.0; }
    
    // Getters de colecciones y datos
    public List<Producto> getProductos() { return productos; }
    public List<Cliente> getClientes() { return clientes; }
    public List<Venta> getHistorialVentas() { return historialVentas; }
    public void setNombreSistema(String nombreSistema) { this.nombreSistema = nombreSistema; }
    public String getNombreSistema() { return nombreSistema; }
    
    // MAIN
    public static void main(String[] args) {
        Farmacia miFarmacia = new Farmacia("Farmacia La Donjuana");

        System.out.println("\n>>> Iniciando Interfaz de Login...");
        // Iniciar la aplicación con la ventana de Login
        SwingUtilities.invokeLater(() -> {

            new LoginWindow(miFarmacia); 
        });
    }
}