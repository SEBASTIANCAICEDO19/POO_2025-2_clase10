package GUI;

import com.mycompany.farmacia.ArticuloGeneral;
import com.mycompany.farmacia.Cliente;
import com.mycompany.farmacia.DetalleVenta;
import com.mycompany.farmacia.Farmacia;
import com.mycompany.farmacia.Medicamento;
import com.mycompany.farmacia.Producto;
import com.mycompany.farmacia.Venta;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MenuPrincipal extends JFrame {
    private Farmacia farmacia;
    private JTabbedPane tabbedPane;
    
    // Variables para el Módulo de Ventas
    private Venta ventaActual;
    private JTextArea areaCarrito;
    private JTextArea areaInventario;
    private JTextArea areaReportes;

    public MenuPrincipal(Farmacia farmacia) {
        this.farmacia = farmacia;
        setTitle("Sistema de Regencia Farmacia (POO)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        tabbedPane = new JTabbedPane();
        
        tabbedPane.addTab("🛒 PUNTO DE VENTA", crearPanelVentas());
        tabbedPane.addTab("📦 INVENTARIO", crearPanelInventario());
        tabbedPane.addTab("👤 CLIENTES", crearPanelRegistroCliente());
        tabbedPane.addTab("💰 REPORTES", crearPanelReportes());
        
        add(tabbedPane);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        
        actualizarInventarioUI();
        actualizarReportesUI();
    }

    // --- MÓDULO 1: VENTAS CON CARRITO
    private JPanel crearPanelVentas() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        
        // Panel de Controles
        JPanel panelEntrada = new JPanel(new GridLayout(6, 2, 5, 10)); 
        panelEntrada.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JTextField txtIDCliente = new JTextField(15);
        JButton btnIniciarVenta = new JButton("1. Iniciar Venta (Buscar Cliente)");
        
        JTextField txtCodProd = new JTextField(15);
        JTextField txtCant = new JTextField(15);
        JCheckBox chkReceta = new JCheckBox("Receta Física Presentada");
        JButton btnAgregar = new JButton("2. Agregar al Carrito");
        
        // Desactivamos controles de producto
        txtCodProd.setEnabled(false);
        txtCant.setEnabled(false);
        chkReceta.setEnabled(false);
        btnAgregar.setEnabled(false);

        // -- SECCIÓN CLIENTE
        panelEntrada.add(new JLabel("ID Cliente:", SwingConstants.RIGHT));
        panelEntrada.add(txtIDCliente);
        panelEntrada.add(new JLabel("")); 
        panelEntrada.add(btnIniciarVenta);
        
        // -- SECCIÓN PRODUCTO
        panelEntrada.add(new JLabel("Cód. Producto:", SwingConstants.RIGHT));
        panelEntrada.add(txtCodProd);
        
        panelEntrada.add(new JLabel("Cantidad:", SwingConstants.RIGHT));
        panelEntrada.add(txtCant);
        
        panelEntrada.add(new JLabel("Validación Receta:", SwingConstants.RIGHT));
        panelEntrada.add(chkReceta);
        
        // Botón Agregar
        panelEntrada.add(new JLabel("")); 
        panelEntrada.add(btnAgregar); 


        // 2. Área Visual del Carrito
        areaCarrito = new JTextArea(">>> Esperando inicio de venta...\n", 10, 40);
        areaCarrito.setEditable(false);
        areaCarrito.setFont(new Font("Monospaced", Font.PLAIN, 12));

        // 3. Panel de Botones Finales
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnFinalizar = new JButton("3. Finalizar Compra");
        JButton btnFactura = new JButton("4. Exportar Factura TXT");
        JButton btnCancelar = new JButton("Cancelar / Nueva");
        
        btnFinalizar.setEnabled(false);
        btnFactura.setEnabled(false);

        panelBotones.add(btnFinalizar);
        panelBotones.add(btnFactura);
        panelBotones.add(btnCancelar);

        // --- LÓGICA DE BOTONES

        // A. INICIAR VENTA
        btnIniciarVenta.addActionListener(e -> {
            String id = txtIDCliente.getText().trim();
            Cliente c = farmacia.buscarClientePorID(id);
            if (c != null) {
                ventaActual = new Venta(c);
                areaCarrito.setText("CLIENTE: " + c.getNombre() + " (ID: " + c.getId() + ")\n");
                areaCarrito.append("------------------------------------------------\n");
                
                // Habilitar controles
                txtIDCliente.setEditable(false);
                btnIniciarVenta.setEnabled(false);
                txtCodProd.setEnabled(true);
                txtCant.setEnabled(true);
                chkReceta.setEnabled(true);
                btnAgregar.setEnabled(true);
                btnCancelar.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "Cliente no encontrado. Registrelo primero.");
            }
        });

        // B. AGREGAR PRODUCTO
        btnAgregar.addActionListener(e -> {
            try {
                String cod = txtCodProd.getText().trim();
                int cant = Integer.parseInt(txtCant.getText().trim());
                boolean recetaFisica = chkReceta.isSelected();
                
                Producto p = farmacia.buscarProductoPorCodigo(cod);
                
                if (p == null) {
                    JOptionPane.showMessageDialog(this, "Producto no existe.");
                    return;
                }
                
                if (cant <= 0) {
                     JOptionPane.showMessageDialog(this, "Cantidad debe ser mayor a 0.");
                     return;
                }

                // Validación de Stock
                if (p.getStockDisponible() < cant) {
                    JOptionPane.showMessageDialog(this, "Stock insuficiente. Disponible: " + p.getStockDisponible());
                    return;
                }
                
                // Validación de Receta Médica
                if (p.isRequiereReceta()) {
                    if (!ventaActual.getCliente().isTieneRecetaRegistrada() && !recetaFisica) {
                        JOptionPane.showMessageDialog(this, "VENTA DENEGADA: Se requiere receta médica para " + p.getNombre());
                        return;
                    }
                }

                // Agregar a la Venta (Esto ya descuenta el stock en la clase Venta)
                ventaActual.agregarDetalle(p, cant);
                
                // Feedback visual
                areaCarrito.append(String.format(" + %-15s x%d  = $%.2f\n", p.getNombre(), cant, (p.getPrecio()*cant)));
                areaCarrito.append("   (Total Parcial: $" + ventaActual.getTotal() + ")\n");
                
                // Limpiar campos
                txtCodProd.setText("");
                txtCant.setText("");
                chkReceta.setSelected(false);
                
                btnFinalizar.setEnabled(true);
                actualizarInventarioUI(); // Refrescar tabla inventario

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: La cantidad debe ser numérica.");
            }
        });

        // C. FINALIZAR COMPRA
        btnFinalizar.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "¿Confirmar venta por un total de $" + ventaActual.getTotal() + "?");
                
            if (confirm == JOptionPane.YES_OPTION) {
                farmacia.registrarVentaTerminada(ventaActual);
                
                areaCarrito.append("\n==================================\n");
                areaCarrito.append(" VENTA FINALIZADA CON ÉXITO.\n");
                areaCarrito.append("==================================\n");
                
                // Bloquear edición
                txtCodProd.setEnabled(false);
                txtCant.setEnabled(false);
                btnAgregar.setEnabled(false);
                btnFinalizar.setEnabled(false);
                
                // Habilitar Factura
                btnFactura.setEnabled(true);
                actualizarReportesUI();
            }
        });

        // D. EXPORTAR FACTURA
        btnFactura.addActionListener(e -> {
            ventaActual.generarFacturaTXT();
            JOptionPane.showMessageDialog(this, "Factura guardada en la carpeta del proyecto.");
        });

        // E. CANCELAR / NUEVA
        btnCancelar.addActionListener(e -> {
            // Restaurar stock si no se finalizó la venta
            if (ventaActual != null && btnFinalizar.isEnabled()) {
                 for(DetalleVenta dt : ventaActual.getCarrito()) {
                     dt.getProducto().setStockDisponible(dt.getProducto().getStockDisponible() + dt.getCantidad());
                 }
                 JOptionPane.showMessageDialog(this, "Venta cancelada. Stock restaurado.");
                 actualizarInventarioUI();
            }
            
            // Reiniciar UI
            ventaActual = null;
            areaCarrito.setText(">>> Esperando inicio de venta...\n");
            txtIDCliente.setText("");
            txtIDCliente.setEditable(true);
            btnIniciarVenta.setEnabled(true);
            
            txtCodProd.setEnabled(false);
            txtCant.setEnabled(false);
            chkReceta.setEnabled(false);
            btnAgregar.setEnabled(false);
            btnFinalizar.setEnabled(false);
            btnFactura.setEnabled(false);
        });

        panel.add(new JLabel("Módulo de Facturación y Ventas", SwingConstants.CENTER), BorderLayout.NORTH);
        panel.add(panelEntrada, BorderLayout.WEST);
        panel.add(new JScrollPane(areaCarrito), BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);
        
        return panel;
    }

    // --- MÓDULO 2: INVENTARIO
    private JPanel crearPanelInventario() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        areaInventario = new JTextArea(15, 50);
        areaInventario.setEditable(false);
        
        // --- A. Panel de Registro de Nuevo Producto ---
        JPanel panelRegistro = new JPanel(new GridLayout(7, 2, 5, 5));
        panelRegistro.setBorder(BorderFactory.createTitledBorder("Registrar Nuevo Producto"));

        JTextField txtRegNombre = new JTextField();
        JTextField txtRegCodigo = new JTextField();
        JTextField txtRegPrecio = new JTextField();
        JTextField txtRegStock = new JTextField();
        JCheckBox chkRegReceta = new JCheckBox("Requiere Receta");
        JTextField txtRegPrincipioActivo = new JTextField();
        JButton btnRegistrarNuevo = new JButton("Registrar Producto Único");

        panelRegistro.add(new JLabel("Nombre:", SwingConstants.RIGHT));
        panelRegistro.add(txtRegNombre);
        panelRegistro.add(new JLabel("Código:", SwingConstants.RIGHT));
        panelRegistro.add(txtRegCodigo);
        panelRegistro.add(new JLabel("Precio ($):", SwingConstants.RIGHT));
        panelRegistro.add(txtRegPrecio);
        panelRegistro.add(new JLabel("Stock Inicial:", SwingConstants.RIGHT));
        panelRegistro.add(txtRegStock);
        panelRegistro.add(new JLabel("Tipo / Receta:", SwingConstants.RIGHT));
        panelRegistro.add(chkRegReceta); // Usaremos la receta para determinar si es Medicamento

        // Campo extra para Medicamentos (Principio Activo)
        panelRegistro.add(new JLabel("Principio Activo:", SwingConstants.RIGHT));
        panelRegistro.add(txtRegPrincipioActivo);
        
        panelRegistro.add(new JLabel(""));
        panelRegistro.add(btnRegistrarNuevo);

        // --- B. Panel de Sumar Stock (Modificación de existente)
        JPanel panelStock = new JPanel(new FlowLayout());
        panelStock.setBorder(BorderFactory.createTitledBorder("Añadir Stock a Existente"));
        JTextField txtStockCodigo = new JTextField(10);
        JTextField txtStockCantidad = new JTextField(5);
        JButton btnAgregarStock = new JButton("Sumar Stock");
        
        panelStock.add(new JLabel("Cód:"));
        panelStock.add(txtStockCodigo);
        panelStock.add(new JLabel("Cant:"));
        panelStock.add(txtStockCantidad);
        panelStock.add(btnAgregarStock);
        
        // Contenedor para los dos formularios
        JPanel panelFormularios = new JPanel(new GridLayout(1, 2, 10, 10));
        panelFormularios.add(panelRegistro);
        panelFormularios.add(panelStock);
        
        // --- LÓGICA DE EVENTOS ---
        
        // 1. REGISTRAR NUEVO PRODUCTO
        btnRegistrarNuevo.addActionListener(e -> {
            try {
                String nombre = txtRegNombre.getText().trim();
                String codigo = txtRegCodigo.getText().trim();
                double precio = Double.parseDouble(txtRegPrecio.getText().trim());
                int stock = Integer.parseInt(txtRegStock.getText().trim());
                boolean requiereReceta = chkRegReceta.isSelected();
                String principioActivo = txtRegPrincipioActivo.getText().trim();

                if (farmacia.buscarProductoPorCodigo(codigo) != null) {
                    JOptionPane.showMessageDialog(this, "Error: El código de producto ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                Producto nuevoProducto;
                
                
                if (requiereReceta || !principioActivo.isEmpty()) {
                    // Creamos un Medicamento
                    nuevoProducto = new Medicamento(nombre, codigo, precio, stock, requiereReceta, principioActivo);
                } else {
                    // Creamos un Artículo General
                    nuevoProducto = new ArticuloGeneral(nombre, codigo, precio, stock);
                }

                farmacia.registrarProducto(nuevoProducto);
                JOptionPane.showMessageDialog(this, "Producto registrado con éxito: " + nombre);
                
                // Limpiar campos y actualizar UI
                txtRegNombre.setText("");
                txtRegCodigo.setText("");
                txtRegPrecio.setText("");
                txtRegStock.setText("");
                chkRegReceta.setSelected(false);
                txtRegPrincipioActivo.setText("");
                actualizarInventarioUI();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error: Precio o Stock deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                 JOptionPane.showMessageDialog(this, "Error al registrar el producto: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // 2. SUMAR STOCK A EXISTENTE
        btnAgregarStock.addActionListener(e -> {
            try {
                String codigo = txtStockCodigo.getText().trim();
                int cantidad = Integer.parseInt(txtStockCantidad.getText().trim());
                if (farmacia.agregarStock(codigo, cantidad)) {
                    JOptionPane.showMessageDialog(this, "Stock actualizado.");
                    txtStockCodigo.setText("");
                    txtStockCantidad.setText("");
                    actualizarInventarioUI();
                } else {
                    JOptionPane.showMessageDialog(this, "Producto no encontrado.");
                }
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error numérico en cantidad."); }
        });
        
        // --- ENSAMBLAJE FINAL ---
        panel.add(new JLabel("Inventario y Registro de Productos", SwingConstants.CENTER), BorderLayout.NORTH);
        panel.add(new JScrollPane(areaInventario), BorderLayout.CENTER);
        panel.add(panelFormularios, BorderLayout.SOUTH);
        return panel;
    }

    // --- MÓDULO 3: REGISTRO CLIENTES
    private JPanel crearPanelRegistroCliente() {

        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        
        // 1. Panel para el formulario
        JPanel panelFormulario = new JPanel(new GridLayout(8, 2, 10, 10));
        
        // Creamos los componentes
        JTextField txtRegNombre = new JTextField(20); // Ancho restringido
        JTextField txtRegID = new JTextField(20);
        JCheckBox chkRegReceta = new JCheckBox("Tiene receta registrada");
        JButton btnRegistrar = new JButton("Registrar Cliente");

        panelFormulario.add(new JLabel("Nombre:", SwingConstants.LEFT)); 
        panelFormulario.add(txtRegNombre);
        
        panelFormulario.add(new JLabel("ID:", SwingConstants.LEFT)); 
        panelFormulario.add(txtRegID);
        
        panelFormulario.add(new JLabel("Receta:", SwingConstants.LEFT)); 
        panelFormulario.add(chkRegReceta);
        
        panelFormulario.add(new JLabel("")); 
        panelFormulario.add(btnRegistrar);
        
        // 2. Colocar el panelFormulario en el centro
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.anchor = GridBagConstraints.CENTER;
        
        panelPrincipal.add(panelFormulario, gbc);
        
        // 3. Lógica del botón
        btnRegistrar.addActionListener(e -> {
            farmacia.registrarCliente(new Cliente(txtRegNombre.getText(), txtRegID.getText(), chkRegReceta.isSelected()));
            JOptionPane.showMessageDialog(this, "Cliente Registrado.");
            txtRegNombre.setText(""); 
            txtRegID.setText("");
            chkRegReceta.setSelected(false);
        });
        
        return panelPrincipal;
    }
    
    // --- MÓDULO 4: REPORTES ---
    private JPanel crearPanelReportes() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        areaReportes = new JTextArea();
        areaReportes.setEditable(false);
        areaReportes.setFont(new Font("Monospaced", Font.PLAIN, 14));
        
        // --- Panel de Controles (Norte) ---
        JPanel panelControles = new JPanel(new GridLayout(3, 3, 10, 5));
        panelControles.setBorder(BorderFactory.createTitledBorder("Gestión y Exportación"));
        
        JTextField txtGastoInicial = new JTextField(10);
        JButton btnFijarGasto = new JButton("Fijar Gasto Base");
        JButton btnResetGasto = new JButton("Gasto a $0.00");
        
        JTextField txtNombreReporte = new JTextField("Reporte_Farmacia", 15);
        JButton btnExportar = new JButton("Exportar Reporte TXT");
        JButton btnUpdate = new JButton("Actualizar Reportes");
        
        // Fila 1: Gasto
        panelControles.add(new JLabel("Nuevo Gasto Base ($):", SwingConstants.RIGHT));
        panelControles.add(txtGastoInicial);
        panelControles.add(btnFijarGasto);
        
        // Fila 2: Reset y Actualizar
        panelControles.add(new JLabel("Opciones:", SwingConstants.RIGHT));
        panelControles.add(btnResetGasto);
        panelControles.add(btnUpdate);
        
        // Fila 3: Exportación
        panelControles.add(new JLabel("Nombre Archivo:", SwingConstants.RIGHT));
        panelControles.add(txtNombreReporte);
        panelControles.add(btnExportar);

        // --- LÓGICA DE BOTONES ---
        
        // 1. FIJAR GASTO BASE
        btnFijarGasto.addActionListener(e -> {
            try {
                double nuevoGasto = Double.parseDouble(txtGastoInicial.getText().trim());
                farmacia.setGastosTotales(nuevoGasto);
                JOptionPane.showMessageDialog(this, "Gasto base fijado en $" + String.format("%.2f", nuevoGasto));
                actualizarReportesUI();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese un valor numérico válido para el gasto.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // 2. RESET GASTO A CERO
        btnResetGasto.addActionListener(e -> {
            farmacia.resetGastos();
            JOptionPane.showMessageDialog(this, "El total de gastos ha sido reseteado a $0.00.");
            actualizarReportesUI();
        });
        
        // 3. ACTUALIZAR REPORTE (Lógica ya existente)
        btnUpdate.addActionListener(e -> actualizarReportesUI());
        
        // 4. EXPORTAR REPORTE
        btnExportar.addActionListener(e -> {
            String nombreBase = txtNombreReporte.getText().trim();
            if (nombreBase.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe ingresar un nombre para el archivo.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            generarReporteTXT(nombreBase);
        });
        
        // --- ENSAMBLAJE FINAL ---
        panel.add(panelControles, BorderLayout.NORTH);
        panel.add(new JScrollPane(areaReportes), BorderLayout.CENTER);
        
        actualizarReportesUI(); // Cargar datos iniciales
        return panel;
    }
    
    // --- NUEVA FUNCIÓN AUXILIAR PARA GENERAR REPORTE TXT ---
    private void generarReporteTXT(String nombreBase) {
        String nombreArchivo = nombreBase + "_" + System.currentTimeMillis() + ".txt";
        
        try (java.io.FileWriter writer = new java.io.FileWriter(nombreArchivo)) {
            
            // 1. Escribir Resumen Financiero
            writer.write("=========================================\n");
            writer.write("        REPORTE FINANCIERO DE FARMACIA     \n");
            writer.write("=========================================\n");
            writer.write(String.format("Fecha de Generación: %s\n", java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME)));
            writer.write("-----------------------------------------\n");
            writer.write(String.format("INGRESOS TOTALES: $%.2f\n", farmacia.getIngresosTotales()));
            writer.write(String.format("GASTOS TOTALES:   $%.2f\n", farmacia.getGastosTotales()));
            writer.write(String.format("GANANCIAS NETAS:  $%.2f\n", farmacia.getGananciasNetas()));
            writer.write("-----------------------------------------\n");
            writer.write(String.format("CLIENTES REGISTRADOS: %d\n", farmacia.getClientes().size()));
            writer.write("\n");
            
            // 2. Escribir Historial de Ventas Detallado
            writer.write("=========================================\n");
            writer.write("         HISTORIAL DE VENTAS DETALLE     \n");
            writer.write("=========================================\n");
            
            for (Venta v : farmacia.getHistorialVentas()) {
                writer.write(String.format("VENTA ID: %s | CLIENTE: %s | TOTAL: $%.2f\n", 
                                            v.getCliente().getId(), v.getCliente().getNombre(), v.getTotal()));
                for (DetalleVenta dv : v.getCarrito()) {
                     writer.write(String.format("  -> %s | Cant: %d | Subtotal: $%.2f\n", 
                                                 dv.getProducto().getNombre(), dv.getCantidad(), dv.getSubtotal()));
                }
                writer.write("-----------------------------------------\n");
            }

            JOptionPane.showMessageDialog(this, "Reporte exportado como: " + nombreArchivo);

        } catch (java.io.IOException e) {
            JOptionPane.showMessageDialog(this, "Error al escribir el archivo: " + e.getMessage(), "Error de Exportación", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void actualizarInventarioUI() {
        StringBuilder sb = new StringBuilder();
        sb.append("CÓDIGO | NOMBRE                  | PRECIO   | STOCK | RECETA\n");
        sb.append("-------|-------------------------|----------|-------|-------\n");
        for (Producto p : farmacia.getProductos()) {
            sb.append(String.format("%-6s | %-23s | $%-7.2f | %-5d | %s\n",
                p.getCodigo(), p.getNombre(), p.getPrecio(), p.getStockDisponible(), (p.isRequiereReceta() ? "SÍ" : "NO")));
        }
        areaInventario.setText(sb.toString());
    }
    
    private void actualizarReportesUI() {
        String reporte = String.format(
            "==================================\n" +
            "       RESUMEN FINANCIERO         \n" +
            "==================================\n" +
            "INGRESOS TOTALES: $%.2f\n" +
            "GASTOS BASE/FIJOS: $%.2f\n" +
            "----------------------------------\n" +
            "GANANCIA NETA: $%.2f\n" +
            "==================================\n" +
            "CLIENTES REGISTRADOS: %d\n" +
            "PRODUCTOS EN INVENTARIO: %d\n",
            farmacia.getIngresosTotales(), farmacia.getGastosTotales(),
            farmacia.getGananciasNetas(), farmacia.getClientes().size(),
            farmacia.getProductos().size()
        );
        areaReportes.setText(reporte);
    }
}