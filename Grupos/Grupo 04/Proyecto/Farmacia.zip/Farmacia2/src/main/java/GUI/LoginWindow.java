package GUI;

import GUI.MenuPrincipal;
import com.mycompany.farmacia.Empleado;
import com.mycompany.farmacia.Farmacia;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginWindow extends JFrame {
    private Farmacia farmacia;
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnLogin;

    public LoginWindow(Farmacia farmacia) {
        this.farmacia = farmacia;
        setTitle("Acceso al Sistema - Farmacia");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new GridLayout(3, 2, 10, 10)); 
        
        setSize(400, 150);
        setLocationRelativeTo(null);
        
        inicializarComponentes();
        configurarListeners();

        setVisible(true);
    }
    
    private void inicializarComponentes() {
        // Inicialización de campos y botón
        txtUsuario = new JTextField(15);
        txtPassword = new JPasswordField(15);
        btnLogin = new JButton("Iniciar Sesión");

        add(new JLabel("Usuario:", SwingConstants.RIGHT));
        add(txtUsuario);
        add(new JLabel("Contraseña:", SwingConstants.RIGHT));
        add(txtPassword);
        add(new JLabel(""));
        add(btnLogin);
        
        //usuario por defecto
        txtUsuario.setText("");
    }
    
    private void configurarListeners() {
        // Lógica del botón de Login
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verificarLogin();
            }
        });
    }

    private void verificarLogin() {
        String usuario = txtUsuario.getText().trim();

        String password = new String(txtPassword.getPassword()); 


        Empleado empleado = farmacia.autenticarUsuario(usuario, password);

        if (empleado != null) {
            //Autenticación exitosa
            JOptionPane.showMessageDialog(this, 
                "Acceso concedido. Bienvenido/a, " + empleado.getNombre(),
                "Login Exitoso",
                JOptionPane.INFORMATION_MESSAGE);
            
            //Cierra la ventana de Login
            dispose();
            
            //Abre la ventana principal de la aplicación
            new MenuPrincipal(farmacia);
            
        } else {
            // 3. Autenticación fallida
            JOptionPane.showMessageDialog(this, 
                "Credenciales incorrectas. Intente nuevamente.", 
                "Error de Login", 
                JOptionPane.ERROR_MESSAGE);
            
            // Limpiar el campo de la contraseña para seguridad
            txtPassword.setText(""); 
            txtUsuario.requestFocus(); // Enfocar el campo de usuario
        }
    }
}