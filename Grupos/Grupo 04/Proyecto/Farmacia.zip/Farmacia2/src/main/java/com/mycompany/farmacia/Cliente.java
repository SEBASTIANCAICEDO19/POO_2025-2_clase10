package com.mycompany.farmacia;

public class Cliente extends Persona {
    private boolean tieneRecetaRegistrada;

    public Cliente(String nombre, String id, boolean tieneRecetaRegistrada) {
        super(nombre, id);
        this.tieneRecetaRegistrada = tieneRecetaRegistrada;
    }

    public boolean isTieneRecetaRegistrada() { return tieneRecetaRegistrada; }

    @Override 
    public void mostrarInfo() {
        super.mostrarInfo();
        String tiene = this.tieneRecetaRegistrada ? "Sí" : "No";
        System.out.println("Tiene Receta Registrada: " + tiene);
    }
}