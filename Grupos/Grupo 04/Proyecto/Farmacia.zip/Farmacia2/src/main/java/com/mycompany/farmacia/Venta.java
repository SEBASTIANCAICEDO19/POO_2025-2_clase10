package com.mycompany.farmacia;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Venta {
    private Cliente cliente;
    private List<DetalleVenta> carrito;
    private double total;
    private LocalDateTime fechaHora;

    public Venta(Cliente cliente) {
        this.cliente = cliente;
        this.carrito = new ArrayList<>();
        this.total = 0.0;
        this.fechaHora = LocalDateTime.now();
    }

    // Método agregar producto al carrito y restar stock
    public void agregarDetalle(Producto producto, int cantidad) {
        DetalleVenta detalle = new DetalleVenta(producto, cantidad);
        this.carrito.add(detalle);
        this.total += detalle.getSubtotal();
        
        // Descontar stock
        producto.setStockDisponible(producto.getStockDisponible() - cantidad);
    }

    public double getTotal() { return total; }
    public Cliente getCliente() { return cliente; }
    public List<DetalleVenta> getCarrito() { return carrito; }

    // MÉTODO FALTANTE AÑADIDO
    public LocalDateTime getFechaHora() { 
        return fechaHora; 
    }

    // Método para generar el archivo TXT
    public void generarFacturaTXT() {
        if (carrito.isEmpty()) {
            System.out.println("Error: Carrito vacío.");
            return;
        }

        String nombreArchivo = "Factura_" + cliente.getId() + "_" + System.currentTimeMillis() + ".txt";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

        try (FileWriter writer = new FileWriter(nombreArchivo)) {
            writer.write("=========================================\n");
            writer.write("           FARMACIA UNAL CENTRAL          \n");
            writer.write("=========================================\n");
            writer.write("Fecha: " + dtf.format(fechaHora) + "\n");
            writer.write("Cliente: " + cliente.getNombre() + "\n");
            writer.write("ID: " + cliente.getId() + "\n");
            writer.write("-----------------------------------------\n");
            writer.write(String.format("%-20s | %-5s | %-10s\n", "PRODUCTO", "CANT", "SUBTOTAL"));
            writer.write("-----------------------------------------\n");

            for (DetalleVenta dv : carrito) {
                writer.write(String.format("%-20s | %-5d | $%-10.2f\n",
                        dv.getProducto().getNombre(),
                        dv.getCantidad(),
                        dv.getSubtotal()));
            }

            writer.write("-----------------------------------------\n");
            writer.write(String.format("TOTAL A PAGAR: $%.2f\n", total));
            writer.write("=========================================\n");
            writer.write("         ¡Gracias por su compra!          \n");

            System.out.println("Factura exportada: " + nombreArchivo);

        } catch (IOException e) {
            System.err.println("Error escribiendo la factura: " + e.getMessage());
        }
    }
}