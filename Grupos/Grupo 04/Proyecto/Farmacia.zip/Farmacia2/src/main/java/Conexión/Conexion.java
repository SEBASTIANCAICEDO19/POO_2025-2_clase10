package Conexión;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    
    private static final String URL = "jdbc:sqlite:bdfarmacia.db";

    public Connection establecerConexion() {
        Connection connection = null;
        try {
            
            Class.forName("org.sqlite.JDBC"); 
            connection = DriverManager.getConnection(URL);
            
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error: No se encontró el driver JDBC de SQLite.", "Error de Driver", JOptionPane.ERROR_MESSAGE);
            System.err.println("Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.", "Error de Conexión", JOptionPane.ERROR_MESSAGE);
            System.err.println("SQL Exception: " + e.getMessage());
        }
        return connection;
    }

    public void cerrarConexion(Connection connection) {
        try {
            if (connection != null) {
                connection.close();
                // System.out.println("Conexión a SQLite cerrada."); // Descomentar para debug
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}