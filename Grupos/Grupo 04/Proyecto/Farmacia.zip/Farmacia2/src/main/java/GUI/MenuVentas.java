package GUI;

import com.mycompany.farmacia.Cliente;
import com.mycompany.farmacia.Farmacia;
import com.mycompany.farmacia.Producto;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuVentas extends JFrame {
    private Farmacia farmacia;
    
    private JTextField txtClienteID;
    private JTextField txtProductoCodigo;
    private JTextField txtCantidad;
    private JCheckBox chkRecetaPresentada;
    private JButton btnProcesarVenta; 
    private JTextArea areaSalida;
    
    public MenuVentas(Farmacia farmacia) {
        this.farmacia = farmacia;
        inicializarComponentes();
        configurarLayout();
    }
    
    private void inicializarComponentes() {
        // --- Paneles y Títulos ---
        setTitle("Sistema de Ventas - Farmacia");
        
        txtClienteID = new JTextField(15);
        txtProductoCodigo = new JTextField(15);
        txtCantidad = new JTextField(15);
        
        chkRecetaPresentada = new JCheckBox("Cliente presenta receta");
        
        // --- Botón de Acción ---
        
        btnProcesarVenta = new JButton("Procesar Venta"); 
        
        btnProcesarVenta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                procesarVentaDesdeUI();
            }
        });
        
        // --- Área de Salida ---
        areaSalida = new JTextArea(8, 30);
        areaSalida.setEditable(false);
        areaSalida.setText("Bienvenido al Punto de Venta.\nIngrese ID de Cliente (123456 o 654321) y Código de Producto.");
    }
    
    private void configurarLayout() {
        setLayout(new BorderLayout(10, 10)); // Layout principal
        JPanel panelEntrada = new JPanel(new GridLayout(4, 2, 10, 10));
        
        // Añadir etiquetas y campos
        panelEntrada.add(new JLabel("ID Cliente:"));
        panelEntrada.add(txtClienteID);
        
        panelEntrada.add(new JLabel("Cód. Producto:"));
        panelEntrada.add(txtProductoCodigo);
        
        panelEntrada.add(new JLabel("Cantidad:"));
        panelEntrada.add(txtCantidad);
        
        // Añadir Receta Checkbox
        panelEntrada.add(new JLabel("Receta Física:"));
        panelEntrada.add(chkRecetaPresentada);
        
        // Contenedor para el botón
        JPanel panelBoton = new JPanel();
        panelBoton.add(btnProcesarVenta);

        // --- Adición a la Ventana ---
        add(panelEntrada, BorderLayout.NORTH);
        add(panelBoton, BorderLayout.CENTER);
        add(new JScrollPane(areaSalida), BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void procesarVentaDesdeUI() {
        String idCliente = txtClienteID.getText().trim();
        String codProducto = txtProductoCodigo.getText().trim();
        String strCantidad = txtCantidad.getText().trim();
        boolean presentaReceta = chkRecetaPresentada.isSelected();

        // 1. Validar entradas básicas
        if (idCliente.isEmpty() || codProducto.isEmpty() || strCantidad.isEmpty()) {
            areaSalida.setText("Error: Todos los campos deben estar llenos.");
            return;
        }
        
        try {
            int cantidad = Integer.parseInt(strCantidad);
            // 2. Buscar Cliente y Producto
            Cliente cliente = farmacia.buscarClientePorID(idCliente);
            Producto producto = farmacia.buscarProductoPorCodigo(codProducto);
            
            if (cliente == null) {
                areaSalida.setText("Error: Cliente con ID " + idCliente + " no encontrado.");
                return;
            }
            if (producto == null) {
                areaSalida.setText("Error: Producto con Código " + codProducto + " no encontrado.");
                return;
            }
            // 3. Procesar Venta
            farmacia.realizarVenta(cliente, producto, cantidad, presentaReceta);

            areaSalida.setText("Venta Procesada. Revise la consola para el recibo detallado.\n"
                             + "Stock actual de " + producto.getNombre() + ": " + producto.getStockDisponible());
            
            // Limpiar campos para la siguiente venta
            txtProductoCodigo.setText("");
            txtCantidad.setText("");
            chkRecetaPresentada.setSelected(false);
            
        } catch (NumberFormatException ex) {
            areaSalida.setText("Error: La cantidad debe ser un número entero.");
        }
    }
}