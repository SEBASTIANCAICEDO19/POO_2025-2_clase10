package Conexión;

import Conexión.Conexion;
import com.mycompany.farmacia.ArticuloGeneral;
import com.mycompany.farmacia.Cliente;
import com.mycompany.farmacia.DetalleVenta;
import com.mycompany.farmacia.Medicamento;
import com.mycompany.farmacia.Producto;
import com.mycompany.farmacia.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import java.time.format.DateTimeFormatter;

public class FarmaciaDAO {

    private Conexion dbConexion;

    public FarmaciaDAO() {
        this.dbConexion = new Conexion();
        crearTablasSiNoExisten();
    }
    
    // MÉTODOS DE ESTRUCTURA DE LA BD

    public void crearTablasSiNoExisten() {
        Connection con = null;
        try {
            con = dbConexion.establecerConexion();
            if (con == null) return;

            try (Statement stmt = con.createStatement()) {
                
                // 1. Tabla CLIENTES
                String sqlClientes = "CREATE TABLE IF NOT EXISTS Clientes ("
                        + "id TEXT PRIMARY KEY NOT NULL, "
                        + "nombre TEXT NOT NULL, "
                        + "tieneRecetaRegistrada BOOLEAN NOT NULL);";
                stmt.execute(sqlClientes);

                // 2. Tabla PRODUCTOS
                String sqlProductos = "CREATE TABLE IF NOT EXISTS Productos ("
                        + "codigo TEXT PRIMARY KEY NOT NULL, "
                        + "nombre TEXT NOT NULL, "
                        + "precio REAL NOT NULL, "
                        + "stockDisponible INTEGER NOT NULL, "
                        + "requiereReceta BOOLEAN NOT NULL, "
                        + "tipo TEXT NOT NULL, " // 'M' o 'A'
                        + "principioActivo TEXT);";
                stmt.execute(sqlProductos);
                
                // 3. Tabla VENTAS (CABECERA)
                String sqlVentas = "CREATE TABLE IF NOT EXISTS Ventas ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "idCliente TEXT NOT NULL, "
                        + "fechaHora TEXT NOT NULL, "
                        + "total REAL NOT NULL, "
                        + "FOREIGN KEY(idCliente) REFERENCES Clientes(id));";
                stmt.execute(sqlVentas);
                
                // 4. Tabla DETALLES_VENTA (LÍNEAS)
                String sqlDetalles = "CREATE TABLE IF NOT EXISTS DetallesVenta ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "ventaId INTEGER NOT NULL, "
                        + "productoCodigo TEXT NOT NULL, "
                        + "cantidad INTEGER NOT NULL, "
                        + "subtotal REAL NOT NULL, "
                        + "FOREIGN KEY(ventaId) REFERENCES Ventas(id), "
                        + "FOREIGN KEY(productoCodigo) REFERENCES Productos(codigo));";
                stmt.execute(sqlDetalles);
                
                System.out.println("Tablas de BD verificadas y creadas si fue necesario.");

            }

        } catch (Exception e) {
            System.err.println("Error creando tablas: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error creando tablas: " + e.toString(), "Error BD", JOptionPane.ERROR_MESSAGE);
        } finally {
            dbConexion.cerrarConexion(con);
        }
    }
    
    // CREATE (REGISTRAR NUEVOS O ACTUALIZAR EXISTENTES)
    
    public void registrarCliente(Cliente c) {
        Connection con = null;
        String sql = "INSERT OR REPLACE INTO Clientes (id, nombre, tieneRecetaRegistrada) VALUES (?, ?, ?)";
        
        try {
            con = dbConexion.establecerConexion();
            if (con == null) return;
            
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, c.getId());
                ps.setString(2, c.getNombre());
                ps.setBoolean(3, c.isTieneRecetaRegistrada());
                ps.executeUpdate();
            }
        } catch (Exception e) {
            System.err.println("Error al registrar cliente en BD: " + e.getMessage());
        } finally {
            dbConexion.cerrarConexion(con);
        }
    }

    public void registrarProducto(Producto p) {
        Connection con = null;
        String sql = "INSERT OR REPLACE INTO Productos (codigo, nombre, precio, stockDisponible, requiereReceta, tipo, principioActivo) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try {
            con = dbConexion.establecerConexion();
            if (con == null) return;
            
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, p.getCodigo());
                ps.setString(2, p.getNombre());
                ps.setDouble(3, p.getPrecio());
                ps.setInt(4, p.getStockDisponible());
                ps.setBoolean(5, p.isRequiereReceta());
                
                // Manejo de polimorfismo
                if (p instanceof Medicamento) {
                    Medicamento m = (Medicamento) p;
                    ps.setString(6, "M"); 
                    ps.setString(7, m.getPrincipioActivo()); 
                } else if (p instanceof ArticuloGeneral) {
                    ps.setString(6, "A"); 
                    ps.setString(7, null); 
                } else {
                    throw new IllegalArgumentException("Tipo de producto no soportado por DAO.");
                }
                
                ps.executeUpdate();
            }
        } catch (Exception e) {
            System.err.println("Error al registrar producto en BD: " + e.getMessage());
        } finally {
            dbConexion.cerrarConexion(con);
        }
    }
    
    public void registrarVenta(Venta venta) {
        Connection con = null;
        String sqlVenta = "INSERT INTO Ventas (idCliente, fechaHora, total) VALUES (?, ?, ?)";
        String sqlDetalle = "INSERT INTO DetallesVenta (ventaId, productoCodigo, cantidad, subtotal) VALUES (?, ?, ?, ?)";
        
        // Define el formato estándar para guardar la fecha y hora
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME; 
        
        try {
            con = dbConexion.establecerConexion();
            if (con == null) return;
            
            con.setAutoCommit(false); 

            // 1. Guardar CABECERA de la Venta y obtener el ID generado
            long ventaId = -1;
            try (PreparedStatement psVenta = con.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS)) {
                psVenta.setString(1, venta.getCliente().getId());
                
                //Formatea LocalDateTime
                psVenta.setString(2, venta.getFechaHora().format(formatter)); 
                
                psVenta.setDouble(3, venta.getTotal());
                psVenta.executeUpdate();

                try (ResultSet generatedKeys = psVenta.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        ventaId = generatedKeys.getLong(1);
                    }
                }
            }

            // 2. Guardar DETALLES
            if (ventaId != -1) {
                try (PreparedStatement psDetalle = con.prepareStatement(sqlDetalle)) {
                    for (DetalleVenta dv : venta.getCarrito()) {
                        psDetalle.setLong(1, ventaId);
                        psDetalle.setString(2, dv.getProducto().getCodigo());
                        psDetalle.setInt(3, dv.getCantidad());
                        psDetalle.setDouble(4, dv.getSubtotal());
                        psDetalle.addBatch(); 
                    }
                    psDetalle.executeBatch(); 
                }
            }
            
            con.commit(); 
            System.out.println("Venta con ID " + ventaId + " guardada en la BD para reportes.");

        } catch (Exception e) {
            System.err.println("Error FATAL al registrar Venta en BD: " + e.getMessage());
            try {
                if (con != null) con.rollback(); 
            } catch (Exception rollbackEx) {
                System.err.println("Error en rollback: " + rollbackEx.getMessage());
            }
        } finally {
            try {
                if (con != null) con.setAutoCommit(true); 
            } catch (Exception e) {/* Ignorar */}
            dbConexion.cerrarConexion(con);
        }
    }
    
    // READ (LEER / OBTENER TODO)

    public List<Cliente> obtenerTodosLosClientes() {
        List<Cliente> listaClientes = new ArrayList<>();
        Connection con = null;
        String sql = "SELECT id, nombre, tieneRecetaRegistrada FROM Clientes";
        
        try {
            con = dbConexion.establecerConexion();
            if (con == null) return listaClientes;
            
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                
                while (rs.next()) {
                    String id = rs.getString("id");
                    String nombre = rs.getString("nombre");
                    boolean tieneReceta = rs.getBoolean("tieneRecetaRegistrada"); 
                    
                    listaClientes.add(new Cliente(nombre, id, tieneReceta));
                }
            }
        } catch (Exception e) {
            System.err.println("Error al leer clientes de la BD: " + e.getMessage());
        } finally {
            dbConexion.cerrarConexion(con);
        }
        return listaClientes;
    }

    public List<Producto> obtenerTodosLosProductos() {
        List<Producto> listaProductos = new ArrayList<>();
        Connection con = null;
        String sql = "SELECT codigo, nombre, precio, stockDisponible, requiereReceta, tipo, principioActivo FROM Productos";
        
        try {
            con = dbConexion.establecerConexion();
            if (con == null) return listaProductos;
            
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                
                while (rs.next()) {
                    String codigo = rs.getString("codigo");
                    String nombre = rs.getString("nombre");
                    double precio = rs.getDouble("precio");
                    int stock = rs.getInt("stockDisponible");
                    boolean receta = rs.getBoolean("requiereReceta");
                    String tipo = rs.getString("tipo");
                    String principioActivo = rs.getString("principioActivo");
                    
                    Producto p;
                    
                    if ("M".equals(tipo)) {
                        p = new Medicamento(nombre, codigo, precio, stock, receta, principioActivo);
                    } else if ("A".equals(tipo)) {
                        p = new ArticuloGeneral(nombre, codigo, precio, stock);
                    } else {
                        continue; 
                    }
                    listaProductos.add(p);
                }
            }
        } catch (Exception e) {
            System.err.println("Error al leer productos de la BD: " + e.getMessage());
        } finally {
            dbConexion.cerrarConexion(con);
        }
        return listaProductos;
    }
    
    // UPDATE (ACTUALIZAR STOCK)
    
    public boolean actualizarStock(String codigoProducto, int nuevoStock) {
        Connection con = null;
        String sql = "UPDATE Productos SET stockDisponible = ? WHERE codigo = ?";
        
        try {
            con = dbConexion.establecerConexion();
            if (con == null) return false;
            
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, nuevoStock);
                ps.setString(2, codigoProducto);
                return ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
            System.err.println("Error al actualizar stock: " + e.getMessage());
            return false;
        } finally {
            dbConexion.cerrarConexion(con);
        }
    }
}