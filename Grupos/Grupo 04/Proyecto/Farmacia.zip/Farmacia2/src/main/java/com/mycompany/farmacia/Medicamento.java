package com.mycompany.farmacia;

public class Medicamento extends Producto {
    private String principioActivo;
    
    public Medicamento(String nombre, String codigo, double precio, int stockDisponible, boolean requiereReceta, String principioActivo) {
        super(nombre, codigo, precio, stockDisponible, requiereReceta);
        this.principioActivo = principioActivo;
    }

    public String getPrincipioActivo() {
        return principioActivo;
    }
    
    @Override // Polimorfismo
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.printf(" | Tipo: Medicamento | Principio Activo: %s\n", this.principioActivo);
    }
}
